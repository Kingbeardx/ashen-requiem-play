Original Xonotic falling vocal is copied unchanged to knight_fall_scream_01.ogg. Source URL: https://raw.githubusercontent.com/xonotic/xonotic-data.pk3dir/e138d021b9fc9d7a1703011eb85661ad00d49f34/sound/player/marine/player/falling.ogg
Dialogue is original local neural synthesis; parameters in voice-admission.json.
